import cv2 as cv
import numpy as np
import math

class LaneSegmentation:
    def pipeline(self, image: np.ndarray) -> np.ndarray:
        """
        Detects lanes ahead in an image
        :param image:
        :return: image with detected lanes
        """
        # Working on a copy of image
        self.image = image.copy()

        # Convert image to grayscale
        gray_img = self.getGrayScaleImage(image)

        # Applying Canny edge detection
        canny_img = self.getCannyImage(gray_img)

        # Isolating the region of interest from Canny Image
        masked_img = self.getRegionofInterest(canny_img)

        # Applying Probabilistic Hough line transform
        hough = self.houghLines(masked_img)

        # Draw lines on the image
        final_image = self.visualizeLines(image, hough)
        return final_image

    def getGrayScaleImage(self, image: np.ndarray) -> np.ndarray:
        """
        Converts 3 channel image into single channel gray scale image
        :param image: Image to be converted to gray scale
        :return: Gray scaled image as an array
        """
        return cv.cvtColor(image, cv.COLOR_RGB2GRAY)

    def getCannyImage(self, image: np.ndarray, threshold1: int=50, threshold2: int=150) -> np.ndarray:
        """
        Applies Canny Image Detection algorithm to an image
        :param image: image as numpy ndarray
        :param threshold1: minimum threshold
        :param threshold2: maximum threshold
        :return: edge image
        """
        return cv.Canny(image, threshold1, threshold2)

    def getRegionofInterest(self, image: np.ndarray) -> np.ndarray:
        """
        Get the region defined by vertices
        :param image: image to get the region from
        :return: ROI
        """

        # Height and Width of the image
        height, width = image.shape[0], image.shape[1]

        # (0,0) is the top left corner
        # A triangular polygon for the masking
        roi = np.array([
            [(0, height), (width/2, height/2), (width, height)]
        ])

        # A zero intensity image to work on with dimensions same as the input image
        mask = np.zeros_like(image)

        # Fills the mask with values 255 that overlaps the region of interest and the other area with 0
        cv.fillPoly(mask, np.int32(roi), 255)

        # Bitwise AND operation on image and mask keeps image only in the region of interest, leaving the rest with mask.
        masked_image = cv.bitwise_and(image, mask)
        return masked_image

    def houghLines(self, image: np.ndarray, threshold=100, minLineLength=100, maxLineGap=50) -> np.ndarray:
        """
        Applies Probabilistic Hough line transform
        :param image: image to apply the transform
        :return: Hough lines
        """
        return cv.HoughLinesP(image, 2, np.pi/180, threshold=threshold, lines=np.array([]), minLineLength=minLineLength, maxLineGap=maxLineGap)

    def calculateCoordinates(self, image: np.ndarray, parameters) -> np.ndarray:
        slope, intercept = parameters

        # point at the bottom of the image
        y1 = image.shape[0]
        # point at the 1/3 of the image from bottom
        y2 = int(y1*2/3)

        # calculate x1 and x2 using y = mx + b
        x1 = int((y1 - intercept) / slope)
        x2 = int((y2 - intercept) / slope)
        return np.array([x1, y1, x2, y2])

    def visualizeLines(self, image, lines):
        left = []
        right = []

        # Loop through all the detected hough lines
        for line in lines:
            # line = [x1,y1, x2,y2]
            x1, y1, x2, y2 = line.flatten()

            # Fits a polynomial line with any degree for the two points (x1,y1) and (x2,y2) and returns slope and intercept
            slope, intercept = np.polyfit((x1, x2), (y1, y2), 1)

            if math.fabs(slope) < 0.5:
                continue
            # If slope is negative, the line is to the left of the lane, and otherwise to the right
            if slope <= 0:
                left.append((slope, intercept))
            else:
                right.append((slope, intercept))

        left_avg = np.average(left, axis=0)
        right_avg = np.average(right, axis=0)

        left_line = self.calculateCoordinates(image, left_avg)
        right_line = self.calculateCoordinates(image, right_avg)

        lines = np.array([left_line, right_line])
        lines_visualize = np.zeros_like(image)

        if lines is not None:
            for x1, y1, x2, y2 in lines:
                cv.line(lines_visualize, (x1, y1), (x2, y2), (0, 0, 255), 8)

        return cv.addWeighted(self.image, 0.8, lines_visualize, 1, 0)